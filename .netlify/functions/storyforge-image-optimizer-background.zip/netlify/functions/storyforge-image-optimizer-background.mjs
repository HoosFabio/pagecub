
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/storyforge-image-optimizer-background.mts
import { createClient } from "@supabase/supabase-js";
import sharp from "sharp";
var SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;
var MINDSTUDIO_API_KEY = process.env.MINDSTUDIO_API_KEY;
var PDF_AGENT_ID = process.env.STORYFORGE_PDF_AGENT_ID;
var APP_URL = process.env.APP_URL || "https://pagecub.com";
var BUCKET = "pdfs";
var MAX_DIM = 2560;
var JPEG_QUALITY = 85;
var storyforge_image_optimizer_background_default = async (req) => {
  let body;
  try {
    body = await req.json();
  } catch {
    console.error("[img-opt] invalid JSON body");
    return;
  }
  const { sfRunId, bookPayload } = body;
  if (!sfRunId || !bookPayload) {
    console.error("[img-opt] missing sfRunId or bookPayload");
    return;
  }
  try {
    await optimize(sfRunId, bookPayload);
  } catch (err) {
    console.error("[img-opt] unhandled error:", err);
  }
};
var config = { path: "/.netlify/functions/storyforge-image-optimizer-background" };
async function optimize(sfRunId, bookPayload) {
  const admin = createClient(SUPABASE_URL, SUPABASE_KEY);
  const chapters = bookPayload.chapters ?? [];
  console.log(`[img-opt] starting \u2014 sfRunId: ${sfRunId}, chapters: ${chapters.length}`);
  let totalOriginalBytes = 0;
  let totalOptimizedBytes = 0;
  for (const ch of chapters) {
    const n = ch.chapter_number;
    const [opt1, orig1, opt1bytes] = await optimizeOne(admin, sfRunId, n, 1, ch.image_1_url);
    ch.image_1_url = opt1;
    totalOriginalBytes += orig1;
    totalOptimizedBytes += opt1bytes;
    const [opt2, orig2, opt2bytes] = await optimizeOne(admin, sfRunId, n, 2, ch.image_2_url);
    ch.image_2_url = opt2;
    totalOriginalBytes += orig2;
    totalOptimizedBytes += opt2bytes;
  }
  const savedMB = ((totalOriginalBytes - totalOptimizedBytes) / 1048576).toFixed(1);
  const totalMB = (totalOptimizedBytes / 1048576).toFixed(1);
  console.log(`[img-opt] done \u2014 original: ${(totalOriginalBytes / 1048576).toFixed(1)}MB, optimized: ${totalMB}MB, saved: ${savedMB}MB`);
  const { data: sfRun } = await admin.from("sf_runs").select("chapters").eq("id", sfRunId).single();
  if (sfRun?.chapters) {
    const chaptersMap = sfRun.chapters;
    for (const ch of chapters) {
      const key = String(ch.chapter_number);
      if (chaptersMap[key]) {
        chaptersMap[key].image_1_optimized = ch.image_1_url;
        chaptersMap[key].image_2_optimized = ch.image_2_url;
      }
    }
    await admin.from("sf_runs").update({ chapters: chaptersMap }).eq("id", sfRunId);
  }
  const pdfCallbackUrl = `${APP_URL}/api/pagecub/callback/pdf/${sfRunId}`;
  const dispatch = await fetch("https://v1.mindstudio-api.com/developer/v2/apps/run", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${MINDSTUDIO_API_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({
      appId: PDF_AGENT_ID,
      workflow: "Main",
      callbackUrl: pdfCallbackUrl,
      variables: {
        payload: JSON.stringify(bookPayload)
      }
    })
  }).catch((err) => {
    console.error("[img-opt] Agent 3B dispatch failed:", err);
    return null;
  });
  if (!dispatch?.ok) {
    const errText = dispatch ? await dispatch.text().catch(() => "") : "fetch error";
    console.error("[img-opt] Agent 3B dispatch HTTP error:", dispatch?.status, errText.slice(0, 200));
    await admin.from("sf_runs").update({
      status: "done",
      packaging_error: "agent_3b_dispatch_failed_from_optimizer",
      completed_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", sfRunId);
    return;
  }
  const dispatchBody = await dispatch.json().catch(() => ({}));
  console.log(`[img-opt] Agent 3B dispatched \u2014 threadId: ${dispatchBody.threadId}`);
}
async function optimizeOne(admin, sfRunId, chapterNum, slot, imageUrl) {
  if (!imageUrl || !imageUrl.startsWith("http")) {
    console.warn(`[img-opt] ch${chapterNum}-${slot}: no URL, skipping`);
    return [imageUrl, 0, 0];
  }
  if (imageUrl.includes(`pagecub/${sfRunId}/images/`)) {
    console.log(`[img-opt] ch${chapterNum}-${slot}: already optimized, skipping`);
    return [imageUrl, 0, 0];
  }
  try {
    const res = await fetch(imageUrl, { signal: AbortSignal.timeout(3e4) });
    if (!res.ok) {
      console.warn(`[img-opt] ch${chapterNum}-${slot}: download failed ${res.status}`);
      return [imageUrl, 0, 0];
    }
    const originalBuffer = Buffer.from(await res.arrayBuffer());
    const originalBytes = originalBuffer.length;
    const optimizedBuffer = await sharp(originalBuffer, { limitInputPixels: false }).rotate().resize({
      width: MAX_DIM,
      height: MAX_DIM,
      fit: "cover",
      position: "center",
      withoutEnlargement: true
    }).flatten({ background: "#ffffff" }).jpeg({
      quality: JPEG_QUALITY,
      mozjpeg: true,
      progressive: false,
      chromaSubsampling: "4:4:4"
    }).toColorspace("srgb").toBuffer();
    const optimizedBytes = optimizedBuffer.length;
    const storagePath = `pagecub/${sfRunId}/images/ch${chapterNum}-${slot}.jpg`;
    const { error: uploadError } = await admin.storage.from(BUCKET).upload(storagePath, optimizedBuffer, {
      contentType: "image/jpeg",
      upsert: true
    });
    if (uploadError) {
      console.warn(`[img-opt] ch${chapterNum}-${slot}: upload failed:`, uploadError.message);
      return [imageUrl, originalBytes, originalBytes];
    }
    const { data: publicUrlData } = admin.storage.from(BUCKET).getPublicUrl(storagePath);
    const optimizedUrl = publicUrlData?.publicUrl ?? imageUrl;
    console.log(
      `[img-opt] ch${chapterNum}-${slot}: ${(originalBytes / 1024).toFixed(0)}KB \u2192 ${(optimizedBytes / 1024).toFixed(0)}KB (${optimizedUrl.slice(-40)})`
    );
    return [optimizedUrl, originalBytes, optimizedBytes];
  } catch (err) {
    console.warn(`[img-opt] ch${chapterNum}-${slot}: error:`, err);
    return [imageUrl, 0, 0];
  }
}
export {
  config,
  storyforge_image_optimizer_background_default as default
};
