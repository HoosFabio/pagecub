
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/storyforge-pdf-download-background.mts
import { createClient } from "@supabase/supabase-js";
var SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
var SUPABASE_KEY = process.env.SUPABASE_SERVICE_KEY;
var DOCRAPTOR_API_KEY = process.env.DOCRAPTOR_API_KEY;
var MAILERSEND_API_KEY = process.env.MAILERSEND_API_KEY;
var PDF_BUCKET = "pdfs";
var FROM_EMAIL = "lumen@inksynth.org";
var FROM_NAME = "PageCub";
var POLL_INTERVAL_MS = 2e4;
var MAX_POLLS = 30;
var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
var storyforge_pdf_download_background_default = async (req) => {
  const body = await req.json().catch(() => ({}));
  const { sfRunId, toolRunId, docraptorStatusId } = body;
  if (!sfRunId || !docraptorStatusId) {
    console.error("[storyforge/pdf-bg] missing sfRunId or docraptorStatusId");
    return;
  }
  try {
    await runBackground(sfRunId, toolRunId, docraptorStatusId);
  } catch (err) {
    console.error("[storyforge/pdf-bg] unhandled error:", err);
  }
};
var config = { path: "/.netlify/functions/storyforge-pdf-download-background" };
async function runBackground(sfRunId, toolRunId, docraptorStatusId) {
  const admin = createClient(SUPABASE_URL, SUPABASE_KEY);
  await admin.from("sf_runs").update({ packaging_status: "bg_polling" }).eq("id", sfRunId);
  console.log(`[storyforge/pdf-bg] started \u2014 sfRunId: ${sfRunId}, statusId: ${docraptorStatusId}`);
  let downloadUrl = null;
  let pageCount = null;
  for (let poll = 0; poll < MAX_POLLS; poll++) {
    if (poll > 0) {
      await sleep(POLL_INTERVAL_MS);
      await admin.from("sf_runs").update({ packaging_status: `bg_poll_${poll}` }).eq("id", sfRunId);
    }
    let statusRes;
    try {
      const res = await fetch(`https://docraptor.com/status/${docraptorStatusId}`, {
        headers: {
          Authorization: `Basic ${Buffer.from(`${DOCRAPTOR_API_KEY}:`).toString("base64")}`
        }
      });
      statusRes = await res.json();
    } catch (err) {
      console.warn(`[storyforge/pdf-bg] poll ${poll} fetch failed:`, err);
      continue;
    }
    const status = String(statusRes.status ?? "").toLowerCase();
    console.log(`[storyforge/pdf-bg] poll ${poll}: status=${status} \u2014 sfRunId: ${sfRunId}`);
    if (status === "completed") {
      downloadUrl = String(statusRes.download_url ?? "").trim();
      pageCount = typeof statusRes.number_of_pages === "number" ? statusRes.number_of_pages : null;
      break;
    }
    if (status === "failed") {
      console.error("[storyforge/pdf-bg] DocRaptor render failed:", statusRes.validation_errors);
      await admin.from("sf_runs").update({
        status: "done",
        packaging_status: "docraptor_failed",
        packaging_error: JSON.stringify(statusRes.validation_errors ?? {}).slice(0, 500),
        docraptor_status: "failed",
        completed_at: (/* @__PURE__ */ new Date()).toISOString()
      }).eq("id", sfRunId);
      await finalizeToolRun(admin, sfRunId, toolRunId);
      return;
    }
  }
  if (!downloadUrl) {
    console.error("[storyforge/pdf-bg] timed out waiting for DocRaptor completion");
    await admin.from("sf_runs").update({
      status: "done",
      packaging_status: "docraptor_timeout",
      packaging_error: "background fn timed out polling DocRaptor",
      completed_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", sfRunId);
    await finalizeToolRun(admin, sfRunId, toolRunId);
    return;
  }
  let pdfBuffer;
  try {
    const pdfRes = await fetch(downloadUrl, {
      headers: {
        Authorization: `Basic ${Buffer.from(`${DOCRAPTOR_API_KEY}:`).toString("base64")}`
      }
    });
    if (!pdfRes.ok) throw new Error(`HTTP ${pdfRes.status}`);
    pdfBuffer = Buffer.from(await pdfRes.arrayBuffer());
    if (pdfBuffer.length === 0) throw new Error("empty PDF \u2014 test doc may allow only one download");
    console.log(`[storyforge/pdf-bg] downloaded ${pdfBuffer.length} bytes \u2014 sfRunId: ${sfRunId}`);
  } catch (err) {
    console.error("[storyforge/pdf-bg] PDF download failed:", err);
    await admin.from("sf_runs").update({
      status: "done",
      packaging_status: "pdf_download_failed",
      packaging_error: String(err).slice(0, 300),
      docraptor_status: "completed",
      completed_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", sfRunId);
    await finalizeToolRun(admin, sfRunId, toolRunId);
    return;
  }
  const storagePath = `pagecub/${sfRunId}/interior.pdf`;
  const { error: uploadError } = await admin.storage.from(PDF_BUCKET).upload(storagePath, pdfBuffer, {
    contentType: "application/pdf",
    upsert: true
  });
  if (uploadError) {
    console.error("[storyforge/pdf-bg] Storage upload failed:", uploadError.message);
    await admin.from("sf_runs").update({
      status: "done",
      packaging_status: "storage_upload_failed",
      packaging_error: uploadError.message.slice(0, 300),
      docraptor_status: "completed",
      completed_at: (/* @__PURE__ */ new Date()).toISOString()
    }).eq("id", sfRunId);
    await finalizeToolRun(admin, sfRunId, toolRunId);
    return;
  }
  const { data: publicUrlData } = admin.storage.from(PDF_BUCKET).getPublicUrl(storagePath);
  const interiorPdfUrl = publicUrlData?.publicUrl ?? "";
  await admin.from("sf_runs").update({
    status: "done",
    interior_pdf_url: interiorPdfUrl,
    pdf_url: interiorPdfUrl,
    packaging_status: "pdf_generated",
    docraptor_status: "completed",
    docraptor_page_count: pageCount,
    expected_page_count: 48,
    pod_package_id: "0850X0850.FC.PRE.CW.080CW444.MXX",
    completed_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", sfRunId);
  await finalizeToolRun(admin, sfRunId, toolRunId, interiorPdfUrl);
  const { data: order } = await admin.from("pagecub_orders").select("id, email").eq("sf_run_id", sfRunId).single();
  if (order) {
    await admin.from("pagecub_orders").update({ status: "done" }).eq("id", order.id);
    const { data: sfRun } = await admin.from("sf_runs").select("book_title, matter, input_payload").eq("id", sfRunId).single();
    if (sfRun) {
      await sendBookEmail(order.email, sfRun, pdfBuffer, interiorPdfUrl).catch(
        (err) => console.error("[storyforge/pdf-bg] delivery email failed:", err)
      );
    }
  }
  console.log(`[storyforge/pdf-bg] \u2713 done \u2014 sfRunId: ${sfRunId}, pages: ${pageCount}, url: ${interiorPdfUrl}`);
}
async function finalizeToolRun(admin, sfRunId, toolRunId, pdfUrl) {
  const { data: sfRun } = await admin.from("sf_runs").select("chapters").eq("id", sfRunId).single();
  const out = {};
  if (pdfUrl) out.pdf_url = pdfUrl;
  for (const [num, ch] of Object.entries(sfRun?.chapters ?? {})) {
    out[`chap${num}_title`] = ch.title ?? "";
    out[`chap${num}_summary`] = ch.summary ?? "";
    out[`chap${num}_text_1`] = ch.text_1 ?? "";
    out[`chap${num}_text_2`] = ch.text_2 ?? "";
    out[`chap${num}_text_1_wc`] = ch.text_1_word_count ?? 0;
    out[`chap${num}_text_2_wc`] = ch.text_2_word_count ?? 0;
    out[`chap${num}_total_wc`] = ch.total_word_count ?? 0;
    out[`chap${num}_image_1`] = ch.image_1 ?? "";
    out[`chap${num}_image_2`] = ch.image_2 ?? "";
  }
  await admin.from("tool_runs").update({
    status: "done",
    output_payload: out,
    completed_at: (/* @__PURE__ */ new Date()).toISOString()
  }).eq("id", toolRunId);
}
async function sendBookEmail(toEmail, sfRun, pdfBuffer, pdfUrl) {
  if (!toEmail) {
    console.warn("[storyforge/pdf-bg] no delivery email provided");
    return;
  }
  const ip = sfRun.input_payload ?? {};
  const matter = sfRun.matter ?? {};
  const bookTitle = String(matter.book_title ?? sfRun.book_title ?? "Your Book");
  const childName = ip.charachter_name || "";
  const safeName = bookTitle.replace(/[^a-z0-9]/gi, "-").toLowerCase();
  const subject = childName ? `${bookTitle} \u2014 ${childName}'s PageCub book is ready!` : `${bookTitle} \u2014 Your PageCub book is ready!`;
  const ATTACH_LIMIT_BYTES = 20 * 1024 * 1024;
  const useAttachment = pdfBuffer.length <= ATTACH_LIMIT_BYTES;
  console.log(`[storyforge/pdf-bg] PDF size: ${(pdfBuffer.length / 1024 / 1024).toFixed(1)}MB \u2014 ${useAttachment ? "attaching" : "link-only (too large)"}`);
  const downloadSection = useAttachment ? `<p style="line-height:1.8;margin:24px 0;">Your personalized illustrated storybook is attached as a PDF. Open it on any device, share with family, or print at home.</p>` : `<p style="line-height:1.8;margin:24px 0;">Your personalized illustrated storybook is ready! Some larger books are too big to send as email attachments \u2014 click the button below to download yours directly.</p>
       <p style="margin:24px 0;"><a href="${pdfUrl}" style="background:#1a1a1a;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;font-family:Georgia,serif;">Download Your Book</a></p>
       <p style="font-size:12px;color:#999;margin-top:8px;">If the button doesn't work, copy this link into your browser: <a href="${pdfUrl}" style="color:#666;">${pdfUrl}</a></p>`;
  const html = `<!DOCTYPE html><html><head><meta charset="UTF-8"></head>
<body style="font-family:Georgia,serif;max-width:600px;margin:0 auto;padding:40px 20px;color:#1a1a1a;">
  <h1 style="font-size:28px;margin-bottom:8px;">\u2728 Your book is ready!</h1>
  <p style="font-size:18px;font-weight:bold;margin-bottom:4px;">${bookTitle}</p>
  ${childName ? `<p style="color:#666;margin-top:0;">A story made for ${childName}.</p>` : ""}
  ${downloadSection}
  <p style="line-height:1.8;">Print fulfillment coming soon \u2014 we'll let you know when hardcover ordering is available.</p>
  <p style="margin-top:32px;font-size:13px;color:#888;">Made with \u2764\uFE0F by PageCub \xB7 <a href="https://pagecub.com" style="color:#888;">pagecub.com</a></p>
</body></html>`;
  const payload = {
    from: { email: FROM_EMAIL, name: FROM_NAME },
    to: [{ email: toEmail }],
    subject,
    html
  };
  if (useAttachment) {
    payload.attachments = [{
      filename: `${safeName}.pdf`,
      content: pdfBuffer.toString("base64"),
      disposition: "attachment"
    }];
  }
  const res = await fetch("https://api.mailersend.com/v1/email", {
    method: "POST",
    headers: { Authorization: `Bearer ${MAILERSEND_API_KEY}`, "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(`MailerSend ${res.status}: ${(await res.text().catch(() => "")).slice(0, 200)}`);
  console.log(`[storyforge/pdf-bg] email sent \u2192 ${toEmail} (${useAttachment ? "attached" : "link-only"})`);
}
export {
  config,
  storyforge_pdf_download_background_default as default
};
