
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);


// netlify/functions/storyforge-chapter-watchdog-background.mts
var SUPABASE_URL = process.env.NEXT_PUBLIC_SUPABASE_URL;
var SUPABASE_SERVICE_KEY = process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;
var MINDSTUDIO_API_KEY = process.env.MINDSTUDIO_API_KEY;
var CHAPTER_AGENT_ID = process.env.STORYFORGE_CHAPTER_AGENT_ID;
var APP_URL = process.env.APP_URL || "https://pagecub.com";
var RETRY_SECRET = process.env.STORYFORGE_RETRY_SECRET || "storyforge-retry-2026";
var SLEEP_BEFORE_FIRST_CHECK_MS = 12 * 60 * 1e3;
var RETRY_INTERVAL_MS = 3 * 60 * 1e3;
var MAX_WATCHDOG_PASSES = 3;
var storyforge_chapter_watchdog_background_default = async (req) => {
  let sfRunId;
  try {
    const body = await req.json();
    sfRunId = body.sfRunId;
  } catch {
    console.error("[watchdog] invalid json body");
    return new Response("bad request", { status: 400 });
  }
  if (!sfRunId) {
    console.error("[watchdog] missing sfRunId");
    return new Response("missing sfRunId", { status: 400 });
  }
  console.log(`[watchdog] started for sfRunId: ${sfRunId}`);
  await sleep(SLEEP_BEFORE_FIRST_CHECK_MS);
  for (let pass = 1; pass <= MAX_WATCHDOG_PASSES; pass++) {
    console.log(`[watchdog] pass ${pass}/${MAX_WATCHDOG_PASSES} \u2014 checking sfRunId: ${sfRunId}`);
    const sfRun = await getSfRun(sfRunId);
    if (!sfRun) {
      console.error(`[watchdog] sf_run not found: ${sfRunId}`);
      return new Response("ok");
    }
    if (sfRun.status !== "chapters_processing") {
      console.log(`[watchdog] sfRun status=${sfRun.status} \u2014 no action needed`);
      return new Response("ok");
    }
    const chapters = sfRun.chapters ?? {};
    const chapterCount = sfRun.chapter_count ?? 10;
    const missing = Array.from({ length: chapterCount }, (_, i) => String(i + 1)).filter((n) => {
      const ch = chapters[n];
      if (!ch) return true;
      if (ch.retrying) return true;
      return false;
    });
    if (missing.length === 0) {
      console.log(`[watchdog] all chapters present \u2014 pass ${pass} no action`);
      return new Response("ok");
    }
    console.log(`[watchdog] pass ${pass}: missing/stuck chapters: ${missing.join(", ")} \u2014 retrying`);
    for (const chapterNum of missing) {
      try {
        const res = await fetch(
          `${APP_URL}/api/pagecub/retry/${sfRunId}/${chapterNum}`,
          {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ secret: RETRY_SECRET })
          }
        );
        const data = await res.json().catch(() => ({}));
        console.log(`[watchdog] retried chapter ${chapterNum}: ${JSON.stringify(data)}`);
      } catch (err) {
        console.error(`[watchdog] error retrying chapter ${chapterNum}:`, err);
      }
    }
    if (pass < MAX_WATCHDOG_PASSES) {
      await sleep(RETRY_INTERVAL_MS);
    }
  }
  console.log(`[watchdog] all passes complete for sfRunId: ${sfRunId}`);
  return new Response("ok");
};
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
async function getSfRun(sfRunId) {
  const res = await fetch(
    `${SUPABASE_URL}/rest/v1/sf_runs?id=eq.${sfRunId}&select=id,status,chapter_count,chapters,input_payload,charachter_bible,visual_bible,chapter_outline,story,book_title,cast_registry`,
    {
      headers: {
        apikey: SUPABASE_SERVICE_KEY,
        Authorization: `Bearer ${SUPABASE_SERVICE_KEY}`
      }
    }
  );
  const data = await res.json().catch(() => []);
  return data[0] ?? null;
}
var config = { path: "/.netlify/functions/storyforge-chapter-watchdog-background" };
export {
  config,
  storyforge_chapter_watchdog_background_default as default
};
